package com.example.MovieCatalog.data.remote.dto

data class Rating(
    val Source: String,
    val Value: String
)