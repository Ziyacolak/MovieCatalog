package com.example.MovieCatalog.util

object Constants {


    const val API_KEY = "3759e23d"
    const val BASE_URL = " https://www.omdbapi.com"
    const val IMDB_ID = "imdb_id"

}