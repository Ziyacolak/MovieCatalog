package com.example.MovieCatalog.domain.model

data class Movie(
    val Poster: String,
    val Title: String,
    val Year: String,
    val imdbID: String
)
