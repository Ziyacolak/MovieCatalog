package com.example.MovieCatalog

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class MovieApplication : Application() {
}